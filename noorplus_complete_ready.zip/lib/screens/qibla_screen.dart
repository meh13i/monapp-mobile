import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class QiblaScreen extends StatefulWidget {
  const QiblaScreen({super.key});
  @override
  State<QiblaScreen> createState() => _QiblaScreenState();
}

class _QiblaScreenState extends State<QiblaScreen> {
  double _bearing = 0;
  String _status = 'Localisation non disponible';

  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

  Future<void> _determinePosition() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      final qibla = _calculateQibla(pos.latitude, pos.longitude);
      setState(() {
        _bearing = qibla;
        _status = 'Qibla calculée';
      });
    } catch (e) {
      setState(() => _status = 'Erreur localisation');
    }
  }

  double _calculateQibla(double lat, double lon) {
    final kaabaLat = 21.422487 * math.pi / 180;
    final kaabaLon = 39.826206 * math.pi / 180;
    final phi = lat * math.pi / 180;
    final lambda = lon * math.pi / 180;
    final y = math.sin(kaabaLon - lambda) * math.cos(kaabaLat);
    final x = math.cos(phi) * math.sin(kaabaLat) - math.sin(phi) * math.cos(kaabaLat) * math.cos(kaabaLon - lambda);
    final bearing = (math.atan2(y, x) * 180 / math.pi + 360) % 360;
    return bearing;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Qibla')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(_status),
            const SizedBox(height:16),
            Transform.rotate(
              angle: (_bearing) * (math.pi / 180) * -1,
              child: const Icon(Icons.arrow_upward, size: 120),
            ),
            const SizedBox(height:12),
            Text('Direction: \${_bearing.toStringAsFixed(1)}°'),
          ],
        ),
      ),
    );
  }
}
