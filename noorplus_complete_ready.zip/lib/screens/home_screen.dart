import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/prayer_service.dart';
import '../widgets/simple_banner.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final prayer = Provider.of<PrayerService>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Noor+')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Card(
              child: ListTile(
                leading: const Icon(Icons.access_time),
                title: const Text('Horaires de prière'),
                subtitle: Text(prayer.times),
              ),
            ),
            const SizedBox(height:12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.explore),
                title: const Text('Qibla'),
                subtitle: const Text('Direction de la Qibla'),
              ),
            ),
            const SizedBox(height:20),
            const SimpleBanner(),
          ],
        ),
      ),
    );
  }
}
