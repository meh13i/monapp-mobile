import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/prayer_service.dart';

class PrayerScreen extends StatelessWidget {
  const PrayerScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final prayer = Provider.of<PrayerService>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Horaires de prière')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(prayer.times, style: const TextStyle(fontSize: 18)),
            const SizedBox(height:16),
            ElevatedButton(
              onPressed: () => prayer.loadPrayerTimes(),
              child: const Text('Rafraîchir'),
            ),
          ],
        ),
      ),
    );
  }
}
