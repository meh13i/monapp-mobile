import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/iap_service.dart';

class SubscriptionScreen extends StatelessWidget {
  const SubscriptionScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final iap = Provider.of<IAPService>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Noor+ Premium')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text('Passez Premium pour supprimer les publicités et débloquer audio Coran et fonctionnalités avancées.', style: TextStyle(fontSize:16)),
            const SizedBox(height:20),
            Card(child: ListTile(title: const Text('Abonnement mensuel'), subtitle: const Text('1.99 €/mois'), trailing: ElevatedButton(onPressed: null, child: const Text('S’abonner')))),
            const SizedBox(height:12),
            Card(child: ListTile(title: const Text('Abonnement annuel'), subtitle: const Text('10.99 €/an'), trailing: ElevatedButton(onPressed: null, child: const Text('S’abonner')))),
            const SizedBox(height:24),
            const Text('Produits détectés:' ),
            ...iap.products.map((p) => Text('- ' + p.title)).toList(),
          ],
        ),
      ),
    );
  }
}
