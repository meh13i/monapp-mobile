import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../services/ads_service.dart';
import 'package:provider/provider.dart';

class SimpleBanner extends StatelessWidget {
  const SimpleBanner({super.key});
  @override
  Widget build(BuildContext context) {
    final ads = Provider.of<AdsService>(context);
    if (ads.bannerAd == null) {
      return const SizedBox(height: 0);
    }
    return SizedBox(
      width: ads.bannerAd!.size.width.toDouble(),
      height: ads.bannerAd!.size.height.toDouble(),
      child: AdWidget(ad: ads.bannerAd!),
    );
  }
}
