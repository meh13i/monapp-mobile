import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class PrayerService extends ChangeNotifier {
  String _times = 'Chargement...';
  String get times => _times;

  Future<void> loadPrayerTimes({double lat = 36.7538, double lng = 3.0588}) async {
    try {
      final url = Uri.parse('https://api.aladhan.com/v1/timings?latitude=\$lat&longitude=\$lng&method=2');
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        final timings = data['data']['timings'];
        _times = 'Fajr \${timings['Fajr']} • Dhuhr \${timings['Dhuhr']} • Asr \${timings['Asr']} • Maghrib \${timings['Maghrib']} • Isha \${timings['Isha']}';
      } else {
        _times = 'Erreur chargement horaires';
      }
    } catch (e) {
      _times = 'Impossible de charger';
    }
    notifyListeners();
  }
}
