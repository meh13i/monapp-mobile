import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdsService {
  BannerAd? _bannerAd;
  BannerAd? get bannerAd => _bannerAd;

  void loadBanner() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-3940256099942544/6300978111', // test banner
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) => print('Ad loaded'),
        onAdFailedToLoad: (ad, err) {
          print('Ad failed: \$err');
          ad.dispose();
        },
      ),
    );
    _bannerAd!.load();
  }

  void disposeBanner() {
    _bannerAd?.dispose();
  }
}
