import 'package:in_app_purchase/in_app_purchase.dart';
import 'dart:async';

class IAPService {
  final _iap = InAppPurchase.instance;
  bool available = false;

  static const String monthlyId = 'noorplus_monthly';
  static const String yearlyId = 'noorplus_yearly';

  List<ProductDetails> products = [];

  Future<void> init() async {
    available = await _iap.isAvailable();
    if (available) {
      final ids = {monthlyId, yearlyId};
      final response = await _iap.queryProductDetails(ids);
      if (response.error != null) {
        print('IAP query error: \${response.error}');
      } else {
        products = response.productDetails;
        if (response.notFoundIDs.isNotEmpty) {
          print('Products not found: \${response.notFoundIDs}');
        }
      }
    }
  }

  Future<void> buy(ProductDetails product) async {
    final param = PurchaseParam(productDetails: product);
    await _iap.buyNonConsumable(purchaseParam: param);
  }
}
