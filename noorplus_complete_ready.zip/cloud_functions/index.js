/*
Cloud Function: verifySubscription
Node.js 18 - deploy to Firebase Functions
This function verifies a subscription purchase with Google Play Developer API.
You must set up service account credentials and give access to the Android Publisher API.
*/
const functions = require('firebase-functions');
const {google} = require('googleapis');

exports.verifySubscription = functions.https.onCall(async (data, context) => {
  const packageName = 'com.noorplus.app';
  const subscriptionId = data.subscriptionId;
  const purchaseToken = data.purchaseToken;

  const auth = new google.auth.GoogleAuth({
    scopes: ['https://www.googleapis.com/auth/androidpublisher'],
  });

  const publisher = google.androidpublisher({
    version: 'v3',
    auth,
  });

  try {
    const res = await publisher.purchases.subscriptions.get({
      packageName: packageName,
      subscriptionId: subscriptionId,
      token: purchaseToken,
    });

    return {
      active: res.data?.autoRenewing || false,
      expiry: res.data?.expiryTimeMillis || 0,
      status: 'OK',
      raw: res.data
    };
  } catch (e) {
    console.error('Verification error', e);
    return {active: false, expiry: 0, status: 'INVALID'};
  }
});
